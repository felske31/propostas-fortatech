# 🚀 Gerador de Propostas Comerciais Forta Tech

Aplicação web moderna, responsiva e profissional para geração de propostas comerciais de alto impacto visual para centros automotivos, oficinas mecânicas e concessionárias.

---

## ✨ Funcionalidades Principais

1. **Preenchimento em Tempo Real (Live Preview)**:
   - Altere dados da proposta, cliente, vendedor, prazos e condições comerciais com atualização instantânea na tela.
2. **Catálogo Pré-configurado Forta Tech**:
   - **Alinhadora 3D Forta Tech Align Advanced** (Sem Rampa, Câmeras 4K, Homologada Volvo/VW).
   - **Balanceadora de Rodas Forta Tech B102** (Levitação Magnética, 512 posições angulares, ASB/SPL).
   - **Desmontadora de Pneus Forta Tech GRIP 500** (Braços Auxiliares Runflat, Aros até 24").
   - **Máquina de Teste e Limpeza de Bicos GDi CNC 605A** (Launch / SmartSafe, Cuba Ultrassônica 3L).
   - **Serviços**: Frete Especial / Descarga e Montagem + Entrega Técnica + Calibração.
3. **Cálculo Financeiro Inteligente**:
   - Controle de Quantidade, Preço de Tabela, Desconto Bonificado por Unidade ou Geral.
   - Cálculo automático de Total Geral e Economia Concedida em R$ (BRL).
4. **Exportação & Impressão de Alta Qualidade**:
   - **Salvar em PDF / Imprimir**: Estilos `@media print` otimizados para páginas A4 sem quebras de layout incorretas.
   - **Exportar HTML Avulso**: Gera um arquivo HTML independente com todas as folhas de estilo embutidas para envio direto por e-mail ao cliente.
5. **Alternador de Temas**:
   - **Dark Tech (Oficial Forta Tech)**: Visual sofisticado e moderno em tons escuros e detalhes em vermelho vibrante.
   - **Clean White**: Visual minimalista com fundo claro perfeito para impressão tradicional.

---

## 🖥️ Como Utilizar

Basta abrir o arquivo `index.html` em qualquer navegador web (Chrome, Edge, Firefox, Safari):

```bash
# Ou via duplo clique no arquivo index.html no seu explorador de arquivos
```

---

## 🛠️ Tecnologias Utilizadas
- HTML5 Semântico
- CSS3 Moderno (CSS Grid, Flexbox, Glassmorphism, CSS Custom Properties)
- JavaScript Vanilla (Reativo, sem dependências externas pesadas)
- Tipografia Google Fonts (`Plus Jakarta Sans` & `Space Grotesk`)
