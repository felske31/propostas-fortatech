@echo off
title Forta Tech - Gerador de Propostas Comerciais
start "" "%~dp0index.html"
exit
